enum token
{
    FDT,
    PROGRAMA,
    LEER,
    ENTERO,
    ESCRIBIR,
    ASIGNACION,
    IDENTIFICADOR,
    CONSTANTE
};
